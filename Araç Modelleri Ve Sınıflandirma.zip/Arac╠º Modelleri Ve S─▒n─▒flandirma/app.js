const express = require('express');
const os = require('os');
const app = express();

const carsData = require('./data/otomobil_fiyatlari.json');

app.set('view engine', 'ejs');
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

function getLocalIp() {
    const interfaces = os.networkInterfaces();
    for (const name of Object.keys(interfaces)) {
        for (const net of interfaces[name]) {
            if (net.family === 'IPv4' && !net.internal) {
                return net.address;
            }
        }
    }
    return 'localhost'; 
}

app.get('/', (req, res) => {
    let results = carsData;
    const { category, search } = req.query;

    if (category && search) {
        results = carsData.filter(car => {
            const regex = new RegExp(search, 'i'); 
            return regex.test(car[category]);
        });
    }

    res.render('index', { cars: results });
});

app.get('/contact', (req, res) => {
    res.render('sayfalar/contact');
});

app.post('/submit-contact', (req, res) => {
    console.log(req.body);  
    res.send('Bizimle iletişime geçtiğiniz için Teşekkürler!');
});

const PORT = process.env.PORT || 3000;
const localIp = getLocalIp();
app.listen(PORT, '0.0.0.0', () => {
    console.log(`\nSunucu http://localhost:${PORT} ve http://${localIp}:${PORT} adreslerinde çalışıyor. 🚀
\nÇıkış yapmak için CTRL+C tuşlarını kullanabilirsiniz. 🚶`);
});
